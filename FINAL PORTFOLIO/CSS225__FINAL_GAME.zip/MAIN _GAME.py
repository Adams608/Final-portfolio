#Adam Gboyega-dixon
# 6/13/2023
import random
import classes
import SECTION_ONE
import SECTION_TWO
player = classes.Player(20,random.randint(1, 20),5)
print("Welcome to the game!")
SECTION_ONE.start_game()
