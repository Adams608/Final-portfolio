#Adam GBoyega-dixon
#css225
#SECTION_THREE
#print stage for story to the user
#create a function to direct the player to the locations():
#create a function for room discription():
    #a tutrtle to help with an image
    #have the user interact with the image
    #a statement that controls the winning and loosing conditions
#End program
def attack(monster):
    print("You attack the monster!, pick a weapon of your choice")
        #print("You get hit by the monster!")
    hit_point = 20
    monster_health = 20
    random_number = random.randint(1,20)
    monster_health = random_number
    damage_monster = hit_point - monster_health
    if damage_monster <= 0:
        print("You have finally defeated the monster")
        print("You won!")
    else:
        if hit_point <= 0 and monster_health > 0:
            print("you loss. Restart the level!")
            exit()

def takedamage(self, damage):
    self.health -= damage
#def take_damage():

     #   if character.is_beaten == True:
    #         beaten : random.randint(1,20)
    #         print  random.randint(1,20)
    #         if player.hit_point <= 0:
    #             print("Your character lost all their hp! You lose!")
    #             print("game over")
    #             exit()
# def defend(player):
#     print("defend!")
#     print("You lose 2 hit points!")
#     player.hp -= 2