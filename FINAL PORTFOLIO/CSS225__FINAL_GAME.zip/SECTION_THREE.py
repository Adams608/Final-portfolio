username = input(" enter your name!")
print("Welcome to stage three of the game", username)
print("At this part of the game, the player is required to navigate his  way around and locate a mountain.\n Once ths player get to the locate the mountain, the player is expected to climb the to the top of the mountain under a certain amount time to be able to get pass through this stage")
import time
counter = 60
while counter < 60:
    print(counter)
    counter -= 2
if counter <= 0:
    print("You've ran out of time and have to begin the stage again")
    print("click the exit button to end the game, and start over button to start the stage over")
    choice = input(" ")
if choice == "exit":
    print("Thanks for playing, you have successfully exited out of the game")
    exit()
elif choice == "continue":
    print("Here is another trial, GAME ON!")

#add an attack ffunction to attack the monster while the counter counts towards 60 seconds

#this while be the winning and loosing condition

# the player has 60 seconds to climb to the top of the mountain
# at the top of the mountain the player get to fight the last monster and win the game