#Adam GBoyega-dixon
#css225
#Main_Character
#Creat a players class with different attributes
class Character:
#define your variables here
    name = ""
    damage = 4
    inventory = []
    hit_points = 20
    skills = ["sword","climbing", "swimming"]
    def attack(self,damage,character):
        print(character.name,"attacks for:", damage, "hit points!")
        character.hit_points -= damage
        return character

global hero
hero = Character()
