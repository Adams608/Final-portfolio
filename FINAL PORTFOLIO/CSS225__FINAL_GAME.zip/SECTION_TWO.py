#Adam Gboyega-dixon
#css225
#SECTION_TWO
import random
story2 = print("Welcome to stage 2, to pass this stage the player must defeat the monster ans also swim to the bittom of the river to ge the other paet of the missing puzzle need in other to get through with the game ")
objects = ["life jacket", "oxygen mask"]
player = input("enter your username")
#def continue():
print("Welcome to stage 2")
print("story2")
    #have a print statement that says "welcome to stage two"
    #have a print statement that print the story of stage two
    #have a variable for the character


#create a function a to move the player

def Move():
    print("story2")
    choice = input("press R1 to dive in the water.\n   press R2 to swim. \n press x to choose nay swimming objects")
    if choice == "R1" and "R2":
        print(story2, "You have to dive to the bottom of the river")
        swim_time = 20
        damage = random.randint(1, 20)
        swim_time -= damage
        if swim_time <= 0:
            print("You  ran out of oxygen, you can no longer swim. \n You loss!")
    else:
        print("Invalid input")
        exit()


    import classes
    goblin = classes.Swim(20, random.randint(1, 20), 5)
    player = classes.Player(20, random.randint(1, 20), 5)
    player.attack(20, random.randint(1, 20), 5)
    goblin.attack(20, random.randint(1, 20), 5)
    print("Player's health is", player.health)
    player.takedamage(goblin.damage)
    print("Player's health is now", player.health)
    print("spider has ", goblin.health, " HP")
    goblin.take_damage(random.randint(1, 20))
    print(goblin.health, "HP left")
    # player.Move(10)
