import random

def takedamage(self,damage):
    self.health -= damage

class Losehealth:
    def __init__(self, health, damage, hit_point):
        self.health = health
        self.damage = damage
        self.hit_point = hit_point
        self.health -= damage
        if self.health <= 0:
            print("You have finally defeated the monster")
            print("You won!")

class Monster:
    def __init__(self, health, damage, hit_point):
        self.health = health
        self.damage = damage
        self.hit_point = hit_point

    def attack(self, health, damage, hit_point):
        print("You have to defeat the monster to complete the mission")
            # print("You get hit by the monster!")
        hit_point = 5
        self.health = 20
        self.damage = random.randint(1, 20)
        self.health -= self.damage
        Losehealth(health, damage, hit_point)
    def takedamage(self, damage):
        self.health -= damage

    def take_damage(self, damage):
        self.health -= damage
        if self.health <= 0:
            print("You have finally defeated the monster")
            print("You won!")
      # Losehealth(health, damage, hit_point)
            # Losehealth(health, damage, hit_point)
    # def losehealth(self,damage):
    #     self.health -= damage

class Player:
    def __init__(self,health,damage, hit_point):
        self.health = health
        self.damage = damage
        self.hit_points = hit_point

    def attack(self, health, damage,hit_point):
        print("You have to defeat the monster to complete the mission")
        # print("You get hit by the monster!")
        hit_point = 5
        self.health = 20
        self.damage = random.randint(1, 20)
        self.health -= self.damage
        Losehealth(health, damage, hit_point)

    def takedamage(self, damage):
        self.health -= damage

    # def take_damage(self, damage):
    #     self.health -= damage
    #     if self.health <= 0:
    #         print("You have finally defeated the monster")
    #         print("You won!")



# def takedamage(self,damage):
#     self.health -= damage
#
spider = Monster(20,random.randint(1, 4), 5)
user = Player(20,random.randint(1, 4), 5)
# global damage
# global hit_point
# global health

# print("Player's health is", Player.health)
# Player.takedamage(spider.damage)
# print("Player's health is now", Player.health)
# print("spider has " ,spider.health, " HP")
# spider.losehealth(10)
# print(spider.health, "HP left")
class Swim:
    def __init__(self, health, damage, hit_point):
        self.health = health
        self.damage = damage
        self.hit_point = hit_point
    def attack(self, health, damage, hit_point):
        print("You have to defeat the monster to complete the mission")
            # print("You get hit by the monster!")
        hit_point = 5
        self.health = 20
        self.damage = random.randint(1, 20)
        self.health -= self.damage
        Losehealth(health, damage, hit_point)
    def Move(self):
        print("story2")
        choice = input("press R1 to dive in the water.\n   press R2 to swim. \n press x to choose nay swimming objects")
        if choice == "R1" and "R2":
            print("You have to dive to the bottom of the river")
            swim_time = 20
            damage = random.randint(1, 20)
            swim_time -= damage
            if swim_time <= 0:
                print("You  ran out of oxygen, you can no longer swim. \n You loss!")
    def take_damage(self, damage):
        self.health -= damage
        if self.health <= 0:
            print("You have finally defeated the monster")
            print("You won!")