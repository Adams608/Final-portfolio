# Adam Gboyega-dixon
# css225
# SECTION_ONE
# THIS SECTION WOULd BE AN INTRODUCTION TO THE GAME
import random
name = input("what is your name?")
player = name
story = ("Welcome to Death Island.\nYou have been stuck on the island for 2 weeks and you must find your way to survive.\n To get pass this stage, there's a giant monster that must defeated")
greet = print("Welcome to the game", name)
weapon = ["sword"]
#print(greet)
def start_game():
    print(greet and story)
    choice = input("Press Y to start and N to end the game, ")
    print(choice)
    while choice != "Y" and choice != "N":
         print('Invalid input!')
         choice = input("Press Y to start and N to end the game, ")
    if choice == 'Y':
        print("Begin this game" + story)
        print("You have to defeat the monster to complete this level")

    else:
        if choice == 'N':
            print("End game")
            exit()
    import classes
    spider = classes.Monster(20,random.randint(1, 20),5)
    player = classes.Player(20,random.randint(1, 20),5 )
    player.attack(20,random.randint(1, 20),5)
    spider.attack(20,random.randint(1, 20),5)
    print("Player's health is", player.health)
    player.takedamage(spider.damage)
    print("Player's health is now", player.health)
    print("spider has " ,spider.health, " HP")
    spider.take_damage(random.randint(1, 20))
    print(spider.health, "HP left")


